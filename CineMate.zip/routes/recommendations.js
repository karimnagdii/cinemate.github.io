// routes/recommendations.js
const express = require('express');
const axios = require('axios');
const router = express.Router();
const db = require('../database');
const verifyToken = require('../middleware/auth');

// Enhanced recommendations with TMDb data
router.get('/', verifyToken, (req, res) => {
  const userId = req.userId;

  // Primary recommendation query: Get movies with highest average rating not yet rated by the user
  const query = `
    SELECT movie_id, AVG(rating) as avg_rating
    FROM ratings
    WHERE movie_id NOT IN (SELECT movie_id FROM ratings WHERE user_id = ?)
    GROUP BY movie_id
    HAVING COUNT(rating) > 1  -- Only consider movies with more than 1 rating
    ORDER BY avg_rating DESC
    LIMIT 10
  `;

  db.all(query, [userId], async (err, rows) => {
    if (err) {
      return res.status(500).send('Error generating recommendations.');
    }

    // Fallback to top-rated movies if no recommendations found
    if (rows.length === 0) {
      const fallbackQuery = `
        SELECT movie_id, AVG(rating) as avg_rating
        FROM ratings
        GROUP BY movie_id
        ORDER BY avg_rating DESC
        LIMIT 10
      `;
      db.all(fallbackQuery, [], async (fallbackErr, fallbackRows) => {
        if (fallbackErr) {
          return res.status(500).send('Error generating fallback recommendations.');
        }
        const enrichedMovies = await enrichWithTmdbData(fallbackRows);
        return res.status(200).json(enrichedMovies);
      });
    } else {
      // Enrich primary recommendations with TMDb data
      const enrichedMovies = await enrichWithTmdbData(rows);
      res.status(200).json(enrichedMovies);
    }
  });
});

// Helper function to enrich movies with TMDb data
async function enrichWithTmdbData(movies) {
  const enrichedMovies = [];

  for (const movie of movies) {
    try {
      const response = await axios.get(`https://api.themoviedb.org/3/movie/${movie.movie_id}`, {
        params: {
          api_key: process.env.TMDB_API_KEY,
        },
      });

      // Add TMDb data to the movie object
      enrichedMovies.push({
        movie_id: movie.movie_id,
        avg_rating: movie.avg_rating,
        title: response.data.title,
        overview: response.data.overview,
        poster_path: response.data.poster_path,
        release_date: response.data.release_date,
      });
    } catch (error) {
      console.error(`Error fetching TMDb data for movie_id ${movie.movie_id}:`, error.message);
    }
  }

  return enrichedMovies;
}

module.exports = router;
